#!/bin/bash

cd /home/ubuntu
pm2 -f start server.js
