# codedeploy-to-ec2-nodejs
Deploy the Nodejs application to EC2 Instance using CodeDeploy
