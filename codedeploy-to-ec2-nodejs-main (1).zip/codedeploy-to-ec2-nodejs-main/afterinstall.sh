#!/bin/bash

cd /home/ubuntu
npm -f install
